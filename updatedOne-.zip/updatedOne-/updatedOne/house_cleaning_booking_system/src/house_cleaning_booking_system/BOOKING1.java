package house_cleaning_booking_system;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;
import javax.swing.JOptionPane;

public class BOOKING1 extends javax.swing.JFrame {

    public void setTimeDisplay() {
        DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("hh:mm a");
        LocalDateTime now = LocalDateTime.now();
        timeDisplay.setText(timeFormat.format(now));
    }

    public void setDateDisplay() {
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDateTime now = LocalDateTime.now();
        timeDisplay1.setText(dateFormat.format(now));
    }

    public BOOKING1() {
        initComponents();
        setTimeDisplay();
        setDateDisplay();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        service = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        PRICINGTXT = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        Confirmbutton = new javax.swing.JButton();
        payment = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        duration = new javax.swing.JTextField();
        PRICINGTXT1 = new javax.swing.JLabel();
        pricing = new javax.swing.JTextField();
        date = new javax.swing.JTextField();
        time = new javax.swing.JTextField();
        ca_txtfullname = new javax.swing.JLabel();
        ca_address = new javax.swing.JTextField();
        ca_txtaddress = new javax.swing.JLabel();
        ca_txtemail = new javax.swing.JLabel();
        ca_email = new javax.swing.JTextField();
        ca_phonenumber = new javax.swing.JTextField();
        ca_txtemail1 = new javax.swing.JLabel();
        PRICINGTXT2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        ca_fullname1 = new javax.swing.JTextField();
        backButton = new javax.swing.JButton();
        timeDisplay1 = new javax.swing.JTextField();
        timeDisplay = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setBackground(new java.awt.Color(204, 204, 255));
        jLabel2.setFont(new java.awt.Font("Verdana", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("BOOKING FORM");
        jLabel2.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 3), "HOUSE CLEANING BOOKING SYSTEM", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Serif", 1, 18), new java.awt.Color(255, 255, 255))); // NOI18N
        jLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 760, 90));

        jPanel3.setBackground(new java.awt.Color(0, 51, 102));
        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 820, 110));

        jPanel4.setBackground(new java.awt.Color(204, 204, 255));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel4.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 5, true));
        jPanel1.setForeground(new java.awt.Color(51, 51, 51));
        jPanel1.setOpaque(false);
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Verdana", 1, 11)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 51, 51));
        jLabel4.setText("FILL IN THE INFORMATION NEEDED:");
        jLabel4.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 250, 30));

        service.setFont(new java.awt.Font("Verdana", 1, 11)); // NOI18N
        service.setForeground(new java.awt.Color(51, 51, 51));
        service.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "BASIC HOUSE CLEANING", "DEEP CLEANING", "LAUNDRY SERVICE", "GREEN CLEANING", "MOVE IN & MOVE OUT", "POST CONSTRUCTION CLEANING" }));
        service.setToolTipText("TYPES OF SERVICE"); // NOI18N
        service.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        service.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        service.setOpaque(false);
        service.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                serviceActionPerformed(evt);
            }
        });
        jPanel1.add(service, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, 210, 30));

        jLabel3.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(51, 51, 51));
        jLabel3.setText("FILL IN THE INFORMATION NEEDED:");
        jLabel3.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 250, 20));

        jLabel11.setFont(new java.awt.Font("Verdana", 1, 11)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(51, 51, 51));
        jLabel11.setText("SELECT SERVICE:");
        jLabel11.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, 120, 20));

        PRICINGTXT.setFont(new java.awt.Font("Verdana", 1, 11)); // NOI18N
        PRICINGTXT.setForeground(new java.awt.Color(51, 51, 51));
        PRICINGTXT.setText("SELECT PAYMENT METHOD:");
        PRICINGTXT.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(PRICINGTXT, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 180, 20));

        jLabel12.setFont(new java.awt.Font("Verdana", 1, 11)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(51, 51, 51));
        jLabel12.setText("SELECT DATE: yyyy-MM-dd");
        jLabel12.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 370, 210, 20));

        Confirmbutton.setBackground(new java.awt.Color(255, 255, 255));
        Confirmbutton.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        Confirmbutton.setForeground(new java.awt.Color(51, 51, 51));
        Confirmbutton.setText("CONFIRM");
        Confirmbutton.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Confirmbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConfirmbuttonActionPerformed(evt);
            }
        });
        jPanel1.add(Confirmbutton, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 390, 100, 30));

        payment.setFont(new java.awt.Font("Verdana", 1, 11)); // NOI18N
        payment.setForeground(new java.awt.Color(51, 51, 51));
        payment.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Bank Transfer", "Gcash", "In Counter Payment", "Door to Door Payment" }));
        payment.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.add(payment, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, 210, 30));

        jLabel6.setFont(new java.awt.Font("Verdana", 1, 11)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(51, 51, 51));
        jLabel6.setText("SELECT TIME : (hh:mm AM/PM)");
        jLabel6.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, 210, 20));

        duration.setEditable(false);
        duration.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        duration.setForeground(new java.awt.Color(51, 51, 51));
        duration.setBorder(null);
        duration.setOpaque(false);
        jPanel1.add(duration, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 190, 130, 20));

        PRICINGTXT1.setBackground(new java.awt.Color(51, 51, 51));
        PRICINGTXT1.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        PRICINGTXT1.setForeground(new java.awt.Color(51, 51, 51));
        PRICINGTXT1.setText("PRICING:");
        PRICINGTXT1.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(PRICINGTXT1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 230, 80, 20));

        pricing.setEditable(false);
        pricing.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        pricing.setForeground(new java.awt.Color(51, 51, 51));
        pricing.setBorder(null);
        pricing.setOpaque(false);
        jPanel1.add(pricing, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 220, 150, 20));
        jPanel1.add(date, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 390, 210, 30));
        jPanel1.add(time, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, 210, 30));

        ca_txtfullname.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        ca_txtfullname.setForeground(new java.awt.Color(255, 255, 255));
        ca_txtfullname.setText("FULLNAME:");
        jPanel1.add(ca_txtfullname, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, -1, -1));

        ca_address.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        ca_address.setForeground(new java.awt.Color(51, 51, 51));
        ca_address.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(ca_address, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 260, 30));

        ca_txtaddress.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        ca_txtaddress.setForeground(new java.awt.Color(255, 255, 255));
        ca_txtaddress.setText("ADDRESS:");
        jPanel1.add(ca_txtaddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, -1, -1));

        ca_txtemail.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        ca_txtemail.setForeground(new java.awt.Color(255, 255, 255));
        ca_txtemail.setText("EMAIL:");
        jPanel1.add(ca_txtemail, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 20, 73, -1));

        ca_email.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        ca_email.setForeground(new java.awt.Color(51, 51, 51));
        ca_email.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(ca_email, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 40, 220, 30));

        ca_phonenumber.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        ca_phonenumber.setForeground(new java.awt.Color(51, 51, 51));
        ca_phonenumber.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(ca_phonenumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 90, 220, 30));

        ca_txtemail1.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        ca_txtemail1.setForeground(new java.awt.Color(255, 255, 255));
        ca_txtemail1.setText("PHONE NO:");
        jPanel1.add(ca_txtemail1, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 70, 90, -1));

        PRICINGTXT2.setBackground(new java.awt.Color(51, 51, 51));
        PRICINGTXT2.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        PRICINGTXT2.setForeground(new java.awt.Color(51, 51, 51));
        PRICINGTXT2.setText("DURATION:");
        PRICINGTXT2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(PRICINGTXT2, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 200, 80, 20));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setText("______________");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 230, 130, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setText("______________");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 200, 130, -1));

        ca_fullname1.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        ca_fullname1.setForeground(new java.awt.Color(51, 51, 51));
        ca_fullname1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(ca_fullname1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 260, 30));

        jPanel4.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, 740, 430));

        backButton.setBackground(new java.awt.Color(255, 255, 255));
        backButton.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        backButton.setForeground(new java.awt.Color(51, 51, 51));
        backButton.setText("BACK");
        backButton.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        backButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backButtonActionPerformed(evt);
            }
        });
        jPanel4.add(backButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 80, 30));

        timeDisplay1.setEditable(false);
        timeDisplay1.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        timeDisplay1.setForeground(new java.awt.Color(51, 51, 51));
        timeDisplay1.setOpaque(false);
        timeDisplay1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                timeDisplay1ActionPerformed(evt);
            }
        });
        jPanel4.add(timeDisplay1, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 10, 90, 30));

        timeDisplay.setEditable(false);
        timeDisplay.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        timeDisplay.setForeground(new java.awt.Color(51, 51, 51));
        timeDisplay.setOpaque(false);
        timeDisplay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                timeDisplayActionPerformed(evt);
            }
        });
        jPanel4.add(timeDisplay, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 10, 90, 30));

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 830, 490));

        setSize(new java.awt.Dimension(841, 642));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents


    private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backButtonActionPerformed
        menu me = new menu();
        me.setVisible(true);
    }//GEN-LAST:event_backButtonActionPerformed

    private void ConfirmbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConfirmbuttonActionPerformed

        String fullname = ca_fullname1.getText();
        String address = ca_address.getText();
        String number = ca_phonenumber.getText();
        String email = ca_email.getText();
        String services = service.getSelectedItem().toString();
        String payments = payment.getSelectedItem().toString();
        String durationSelect = duration.getText();
        String pricingSelect = pricing.getText();
        String inputDate = date.getText();
        String inputTime = time.getText();

        if (!fullname.matches("[a-zA-Z ]+")) {
            JOptionPane.showMessageDialog(this, "Please enter a valid name (only alphabetic characters and spaces)", "Error", JOptionPane.ERROR_MESSAGE);
        } else if (!address.matches("[a-zA-Z0-9 ]+")) {
            JOptionPane.showMessageDialog(this, "Please enter a valid address (only alphabetic characters, spaces, and numbers)", "Error", JOptionPane.ERROR_MESSAGE);
        } else if (!number.matches("[0-9]{11}")) {
            JOptionPane.showMessageDialog(this, "Please enter a valid 11-digit phone number", "Error", JOptionPane.ERROR_MESSAGE);
        } else if (fullname.isEmpty() || address.isEmpty() || number.isEmpty() || email.isEmpty() || services.isEmpty() || payments.isEmpty() || inputDate.isEmpty() || inputTime.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill up the form properly", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            DateFormat timeFormat = new SimpleDateFormat("hh:mm a");
            Date parsedTime;
            try {
                parsedTime = timeFormat.parse(inputTime);
            } catch (ParseException e) {
                JOptionPane.showMessageDialog(null, "Invalid time format (hh:mm a)", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate parsedDate;
            try {
                parsedDate = LocalDate.parse(inputDate, dateFormatter);
            } catch (DateTimeParseException e) {
                JOptionPane.showMessageDialog(null, "Invalid date format (yyyy-MM-dd)", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            int option = JOptionPane.showConfirmDialog(this,
                    "Please confirm the following details:\n\n"
                    + "Full Name: " + fullname + "\n"
                    + "Address: " + address + "\n"
                    + "Phone Number: " + number + "\n"
                    + "Email: " + email + "\n"
                    + "Selected Service: " + services + "\n"
                    + "Payment Method: " + payments + "\n"
                    + "Duration: " + durationSelect + "\n"
                    + "Pricing: " + pricingSelect + "\n"
                    + "Date: " + inputDate + "\n"
                    + "Time: " + inputTime + "\n\n"
                    + "Is everything correct?",
                    "Confirmation",
                    JOptionPane.YES_NO_OPTION);

            if (option == JOptionPane.YES_OPTION) {
                MY_SCHEDULE schedule = new MY_SCHEDULE(fullname, address, number, email, services, payments, durationSelect, pricingSelect, inputDate, inputTime);
                schedule.setVisible(true);
                
                Datas.dName = ca_fullname1.getText();
                Datas.dAddress = ca_address.getText();
                Datas.dEmail = ca_email.getText();
                Datas.dPhoneN = ca_phonenumber.getText();
                
                this.dispose();
            } else if (option == JOptionPane.NO_OPTION) {
                JOptionPane.showMessageDialog(null, "Try again later");
            }
        }
    }//GEN-LAST:event_ConfirmbuttonActionPerformed

    private void serviceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_serviceActionPerformed

        String selectedService = service.getSelectedItem().toString();
        switch (selectedService) {
            case "BASIC HOUSE CLEANING":
                duration.setText("4 hours");
                pricing.setText("3,500");
                break;
            case "DEEP CLEANING":
                duration.setText("6 hours");
                pricing.setText("5,500");
                break;
            case "LAUNDRY SERVICE":
                duration.setText("3 hours");
                pricing.setText("750");
                break;
            case "GREEN CLEANING":
                duration.setText("5 hours");
                pricing.setText("5,000");
                break;
            case "MOVE IN & MOVE OUT":
                duration.setText("3 hours");
                pricing.setText("3,200");
                break;
            case "POST CONSTRUCTION CLEANING":
                duration.setText("4 hours");
                pricing.setText("2,200");
                break;
            default:
                pricing.setText("");
                break;
        }


    }//GEN-LAST:event_serviceActionPerformed

    private void paymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_paymentActionPerformed

    }//GEN-LAST:event_paymentActionPerformed

    private void timeDisplayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_timeDisplayActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_timeDisplayActionPerformed

    private void timeDisplay1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_timeDisplay1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_timeDisplay1ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BOOKING1().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Confirmbutton;
    private javax.swing.JLabel PRICINGTXT;
    private javax.swing.JLabel PRICINGTXT1;
    private javax.swing.JLabel PRICINGTXT2;
    private javax.swing.JButton backButton;
    private javax.swing.JTextField ca_address;
    private javax.swing.JTextField ca_email;
    private javax.swing.JTextField ca_fullname1;
    private javax.swing.JTextField ca_phonenumber;
    private javax.swing.JLabel ca_txtaddress;
    private javax.swing.JLabel ca_txtemail;
    private javax.swing.JLabel ca_txtemail1;
    private javax.swing.JLabel ca_txtfullname;
    private javax.swing.JTextField date;
    private javax.swing.JTextField duration;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JComboBox<String> payment;
    private javax.swing.JTextField pricing;
    private javax.swing.JComboBox<String> service;
    private javax.swing.JTextField time;
    private javax.swing.JTextField timeDisplay;
    private javax.swing.JTextField timeDisplay1;
    // End of variables declaration//GEN-END:variables
}
