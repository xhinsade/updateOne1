package house_cleaning_booking_system;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import javax.swing.JOptionPane; 


public class CREATE_ACCOUNT extends javax.swing.JFrame {

     
String userspath = "C:\\Users\\ITLAB2-PC06-STUDENT\\Documents\\NetBeansProjects\\updatedOne-\\updatedOne\\house_cleaning_booking_system\\accounts.txt";

   
    public CREATE_ACCOUNT() {
        initComponents();
        
    }
     
    public void writeUserData(String username, String password) {
        try {
            try (FileWriter writer = new FileWriter(userspath, true)) {
                writer.write(username + "," + password + "\n");
            }
        } catch (IOException e) {
        }
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jCheckBox1 = new javax.swing.JCheckBox();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        ca_txtfullname = new javax.swing.JLabel();
        ca_txtusername = new javax.swing.JLabel();
        ca_txtpassword = new javax.swing.JLabel();
        ca_fullname = new javax.swing.JTextField();
        ca_username = new javax.swing.JTextField();
        ca_password = new javax.swing.JPasswordField();
        ca_createbutton = new javax.swing.JButton();
        ca_txtemail = new javax.swing.JLabel();
        ca_email = new javax.swing.JTextField();
        ca_txtemail1 = new javax.swing.JLabel();
        ca_phonenumber = new javax.swing.JTextField();
        ca_txtemail2 = new javax.swing.JLabel();
        ca_txtaddress = new javax.swing.JLabel();
        ca_txtgender = new javax.swing.JLabel();
        ca_age = new javax.swing.JTextField();
        ca_address = new javax.swing.JTextField();
        ca_txtemail4 = new javax.swing.JLabel();
        ca_birthdate = new javax.swing.JTextField();
        ca_gender = new javax.swing.JComboBox<>();
        ca_backbutton = new javax.swing.JButton();

        jCheckBox1.setText("jCheckBox1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 51, 102));

        jLabel1.setFont(new java.awt.Font("Verdana", 1, 30)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("HOUSE CLEANING BOOKING SYSTEM");
        jLabel1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 3), "WELCOME TO", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.BELOW_TOP, new java.awt.Font("Serif", 1, 18), new java.awt.Color(255, 255, 255))); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(54, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 750, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(29, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 830, 140));

        jPanel3.setBackground(new java.awt.Color(204, 204, 255));

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 5, true), "CREATE ACCOUNT", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Verdana", 1, 18), new java.awt.Color(51, 51, 51))); // NOI18N
        jPanel1.setOpaque(false);
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ca_txtfullname.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        ca_txtfullname.setForeground(new java.awt.Color(51, 51, 51));
        ca_txtfullname.setText("FULLNAME:");
        jPanel1.add(ca_txtfullname, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, -1, -1));

        ca_txtusername.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        ca_txtusername.setForeground(new java.awt.Color(51, 51, 51));
        ca_txtusername.setText("USERNAME:");
        jPanel1.add(ca_txtusername, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 120, -1, -1));

        ca_txtpassword.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        ca_txtpassword.setForeground(new java.awt.Color(51, 51, 51));
        ca_txtpassword.setText("PASSWORD:");
        jPanel1.add(ca_txtpassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, -1, -1));

        ca_fullname.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        ca_fullname.setForeground(new java.awt.Color(51, 51, 51));
        ca_fullname.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        ca_fullname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ca_fullnameActionPerformed(evt);
            }
        });
        jPanel1.add(ca_fullname, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 80, 219, 30));

        ca_username.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        ca_username.setForeground(new java.awt.Color(51, 51, 51));
        ca_username.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(ca_username, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 140, 218, 30));

        ca_password.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        ca_password.setForeground(new java.awt.Color(51, 51, 51));
        ca_password.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(ca_password, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 200, 218, 30));

        ca_createbutton.setBackground(new java.awt.Color(255, 255, 255));
        ca_createbutton.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        ca_createbutton.setForeground(new java.awt.Color(51, 51, 51));
        ca_createbutton.setText("CREATE");
        ca_createbutton.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        ca_createbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ca_createbuttonActionPerformed(evt);
            }
        });
        jPanel1.add(ca_createbutton, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 370, 120, 40));

        ca_txtemail.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        ca_txtemail.setForeground(new java.awt.Color(51, 51, 51));
        ca_txtemail.setText("EMAIL:");
        jPanel1.add(ca_txtemail, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 50, 73, -1));

        ca_email.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        ca_email.setForeground(new java.awt.Color(51, 51, 51));
        ca_email.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(ca_email, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 70, 210, 30));

        ca_txtemail1.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        ca_txtemail1.setForeground(new java.awt.Color(51, 51, 51));
        ca_txtemail1.setText("PHONE NO:");
        jPanel1.add(ca_txtemail1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 110, 90, -1));

        ca_phonenumber.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        ca_phonenumber.setForeground(new java.awt.Color(51, 51, 51));
        ca_phonenumber.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(ca_phonenumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 130, 210, 30));

        ca_txtemail2.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        ca_txtemail2.setForeground(new java.awt.Color(51, 51, 51));
        ca_txtemail2.setText("AGE:");
        jPanel1.add(ca_txtemail2, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 170, 73, -1));

        ca_txtaddress.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        ca_txtaddress.setForeground(new java.awt.Color(51, 51, 51));
        ca_txtaddress.setText("ADDRESS:");
        jPanel1.add(ca_txtaddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 240, -1, -1));

        ca_txtgender.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        ca_txtgender.setForeground(new java.awt.Color(51, 51, 51));
        ca_txtgender.setText("GENDER:");
        jPanel1.add(ca_txtgender, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 300, -1, -1));

        ca_age.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        ca_age.setForeground(new java.awt.Color(51, 51, 51));
        ca_age.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(ca_age, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 190, 210, 30));

        ca_address.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        ca_address.setForeground(new java.awt.Color(51, 51, 51));
        ca_address.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(ca_address, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 260, 220, 30));

        ca_txtemail4.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        ca_txtemail4.setForeground(new java.awt.Color(51, 51, 51));
        ca_txtemail4.setText("BIRTHDATE:");
        jPanel1.add(ca_txtemail4, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 230, -1, -1));

        ca_birthdate.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        ca_birthdate.setForeground(new java.awt.Color(51, 51, 51));
        ca_birthdate.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(ca_birthdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 250, 210, 30));

        ca_gender.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        ca_gender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Female", "Male", "Prefer not to say" }));
        jPanel1.add(ca_gender, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 330, 210, 30));

        ca_backbutton.setBackground(new java.awt.Color(255, 255, 255));
        ca_backbutton.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        ca_backbutton.setForeground(new java.awt.Color(51, 51, 51));
        ca_backbutton.setText("BACK");
        ca_backbutton.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        ca_backbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ca_backbuttonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ca_backbutton, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 670, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(61, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ca_backbutton, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 441, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(210, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 830, 680));

        setSize(new java.awt.Dimension(849, 642));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
     public void Personal_Info(String fullname,String username,String address,String number,String email,String age,String birthdate, String gender){
             
    }
    private void ca_createbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ca_createbuttonActionPerformed
      
      File f = new File(userspath);
     
    String fullname = ca_fullname.getText().trim();
    String username = ca_username.getText().trim();
    String password = ca_password.getText();
    String address = ca_address.getText().trim();
    String email = ca_email.getText().trim();
    String age = ca_age.getText().trim();
    String number = ca_phonenumber.getText().trim();
    String birthdate = ca_birthdate.getText().trim();
    String gender = ca_gender.getSelectedItem().toString();
    
    int Age = Integer.parseInt(age);

    if (fullname.isEmpty() || !fullname.matches("[a-zA-Z ]+")) {
        JOptionPane.showMessageDialog(this, "Please enter a valid name (only alphabetic characters and spaces)", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (username.isEmpty() || !username.matches("[a-zA-Z0-9]+")) {
        JOptionPane.showMessageDialog(this, "Please enter a valid username (only alphanumeric characters)", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (address.isEmpty() || !address.matches("[a-zA-Z0-9 ]+")) {
        JOptionPane.showMessageDialog(this, "Please enter a valid address (only alphabetic characters, spaces, and numbers)", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    if (number.isEmpty() || !number.matches("\\d{11}")) {
        JOptionPane.showMessageDialog(this, "Please enter a valid 11-digit phone number", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

      if (Age <= 17){
           JOptionPane.showMessageDialog(this, "Please enter a valid age", "Error", JOptionPane.ERROR_MESSAGE);
        return;
       }
    
     DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate parsedDate;
            try {
                parsedDate = LocalDate.parse(birthdate, dateFormatter);
            } catch (DateTimeParseException e) {
                JOptionPane.showMessageDialog(null, "Invalid date format (yyyy-MM-dd)", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
    int option = JOptionPane.showConfirmDialog(null, "Are you sure you want to create this account?", "Confirmation", JOptionPane.YES_NO_OPTION);
    if (option == JOptionPane.YES_OPTION) {
        
        writeUserData(username, password);
        JOptionPane.showMessageDialog(null, "You've successfully created an account");
        Login login = new Login();
        login.setVisible(true);
        this.dispose();
        
        
       PERSONAL_INFO info = new PERSONAL_INFO(fullname, username, address, number, email, age, birthdate, gender);
        info.setVisible(false);
         this.dispose();
    } else {
        JOptionPane.showMessageDialog(null, "Account creation canceled");
    
}


    }//GEN-LAST:event_ca_createbuttonActionPerformed

    private void ca_backbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ca_backbuttonActionPerformed
       Login login = new Login();
       login.setVisible(true);
       this.dispose();
    }//GEN-LAST:event_ca_backbuttonActionPerformed

    private void ca_fullnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ca_fullnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ca_fullnameActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CREATE_ACCOUNT.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
    //</editor-fold>
    
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new CREATE_ACCOUNT().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField ca_address;
    private javax.swing.JTextField ca_age;
    private javax.swing.JButton ca_backbutton;
    private javax.swing.JTextField ca_birthdate;
    private javax.swing.JButton ca_createbutton;
    private javax.swing.JTextField ca_email;
    public javax.swing.JTextField ca_fullname;
    private javax.swing.JComboBox<String> ca_gender;
    private javax.swing.JPasswordField ca_password;
    private javax.swing.JTextField ca_phonenumber;
    private javax.swing.JLabel ca_txtaddress;
    private javax.swing.JLabel ca_txtemail;
    private javax.swing.JLabel ca_txtemail1;
    private javax.swing.JLabel ca_txtemail2;
    private javax.swing.JLabel ca_txtemail4;
    private javax.swing.JLabel ca_txtfullname;
    private javax.swing.JLabel ca_txtgender;
    private javax.swing.JLabel ca_txtpassword;
    private javax.swing.JLabel ca_txtusername;
    private javax.swing.JTextField ca_username;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    // End of variables declaration//GEN-END:variables
}
