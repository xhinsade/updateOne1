package house_cleaning_booking_system;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

 
public final class PERSONAL_INFO extends javax.swing.JFrame {

    public PERSONAL_INFO(){
        initComponents();
        loadDataFromFile();
        
}
    
 private void loadDataFromFile() {
        String userspath = "C:\\Users\\ITLAB2-PC06-STUDENT\\Documents\\NetBeansProjects\\updatedOne-\\updatedOne\\house_cleaning_booking_system\\accounts.txt";

        try (BufferedReader reader = new BufferedReader(new FileReader(userspath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Split the line into fields
                String[] fields = line.split(",");
                // Set fields to corresponding labels
                pi_name.setText(fields[0]);
                pi_username.setText(fields[1]);
                pi_address.setText(fields[2]);
                pi_number.setText(fields[3]);
                pi_email.setText(fields[4]);
                pi_age.setText(fields[5]);
                pi_gender.setText(fields[6]);
                pi_birthdate.setText(fields[7]);
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        t1_txtname = new javax.swing.JLabel();
        t1_txtusername = new javax.swing.JLabel();
        t1_txtaddress = new javax.swing.JLabel();
        t1_txtphonenumber = new javax.swing.JLabel();
        t1_txtemail = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        t1_txtage = new javax.swing.JLabel();
        t1_txtgender = new javax.swing.JLabel();
        t1_txtbirthdate = new javax.swing.JLabel();
        backbutton = new javax.swing.JButton();
        updatebutton1 = new javax.swing.JButton();
        pi_birthdate = new javax.swing.JLabel();
        pi_name = new javax.swing.JLabel();
        pi_username = new javax.swing.JLabel();
        pi_address = new javax.swing.JLabel();
        pi_number = new javax.swing.JLabel();
        pi_email = new javax.swing.JLabel();
        pi_age = new javax.swing.JLabel();
        pi_gender = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 51, 102));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setBackground(new java.awt.Color(204, 204, 255));
        jLabel1.setFont(new java.awt.Font("Verdana", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("PERSONAL INFORMATION");
        jLabel1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 3), "HOUSE CLEANING BOOKING SYSTEM", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Serif", 1, 18), new java.awt.Color(255, 255, 255))); // NOI18N
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 781, 99));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 830, 110));

        jPanel3.setBackground(new java.awt.Color(204, 204, 255));
        jPanel3.setForeground(new java.awt.Color(255, 102, 102));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(153, 153, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 5, true), "", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Serif", 1, 18))); // NOI18N
        jPanel1.setOpaque(false);
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        t1_txtname.setFont(new java.awt.Font("Serif", 1, 11)); // NOI18N
        t1_txtname.setText("NAME:");
        jPanel1.add(t1_txtname, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, 93, 20));

        t1_txtusername.setFont(new java.awt.Font("Serif", 1, 11)); // NOI18N
        t1_txtusername.setText("USERNAME:");
        jPanel1.add(t1_txtusername, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 93, 20));

        t1_txtaddress.setFont(new java.awt.Font("Serif", 1, 11)); // NOI18N
        t1_txtaddress.setText("ADDRESS:");
        jPanel1.add(t1_txtaddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, 93, 21));

        t1_txtphonenumber.setFont(new java.awt.Font("Serif", 1, 11)); // NOI18N
        t1_txtphonenumber.setText("PHONE NUMBER:");
        jPanel1.add(t1_txtphonenumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, 110, 26));

        t1_txtemail.setFont(new java.awt.Font("Serif", 1, 11)); // NOI18N
        t1_txtemail.setText("EMAIL:");
        jPanel1.add(t1_txtemail, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 250, 90, 21));

        jLabel15.setFont(new java.awt.Font("Serif", 1, 12)); // NOI18N
        jLabel15.setText("ADDITIONAL INFO:");
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 10, 150, -1));

        t1_txtage.setFont(new java.awt.Font("Serif", 1, 11)); // NOI18N
        t1_txtage.setText("AGE:");
        jPanel1.add(t1_txtage, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 40, 90, 20));

        t1_txtgender.setFont(new java.awt.Font("Serif", 1, 11)); // NOI18N
        t1_txtgender.setText("GENDER:");
        jPanel1.add(t1_txtgender, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 90, 90, 20));

        t1_txtbirthdate.setFont(new java.awt.Font("Serif", 1, 11)); // NOI18N
        t1_txtbirthdate.setText("BIRTHDATE:");
        jPanel1.add(t1_txtbirthdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 140, 90, 20));

        backbutton.setFont(new java.awt.Font("Serif", 1, 14)); // NOI18N
        backbutton.setText("BACK");
        backbutton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        backbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbuttonActionPerformed(evt);
            }
        });
        jPanel1.add(backbutton, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 270, 100, 30));

        updatebutton1.setFont(new java.awt.Font("Serif", 1, 14)); // NOI18N
        updatebutton1.setText("UPDATE");
        updatebutton1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        updatebutton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatebutton1ActionPerformed(evt);
            }
        });
        jPanel1.add(updatebutton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 270, 100, 30));

        pi_birthdate.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(pi_birthdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 160, 250, 30));

        pi_name.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(pi_name, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 250, 30));

        pi_username.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(pi_username, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 110, 250, 30));

        pi_address.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(pi_address, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 160, 250, 30));

        pi_number.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(pi_number, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, 250, 30));

        pi_email.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(pi_email, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 270, 250, 30));

        pi_age.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(pi_age, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 60, 250, 30));

        pi_gender.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(pi_gender, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 110, 250, 30));

        jPanel3.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 40, 680, 360));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 820, 490));

        setSize(new java.awt.Dimension(835, 642));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    
    
        
    
    private void backbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbuttonActionPerformed
      menu men = new menu();
      men.setVisible(true);
      this.dispose();
    }//GEN-LAST:event_backbuttonActionPerformed

    private void updatebutton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatebutton1ActionPerformed
    
        String fullname = pi_name.getText();
        String username = pi_username.getText();
        String address = pi_address.getText();
        String number = pi_number.getText();
        String email = pi_email.getText();
        String age = pi_age.getText();
        String gender = pi_gender.getText();
        String birthdate = pi_birthdate.getText();
        
        // Call method to save the updated data to the text file
        saveDataToFile(fullname, username, address, number, email, age, birthdate, gender);
    }

    private void saveDataToFile(String fullname, String username, String address, String number, String email, String age, String birthdate, String gender) {
        String filePath = "C:\\Users\\ITLAB2-PC06-STUDENT\\Documents\\NetBeansProjects\\updatedOne-\\updatedOne\\house_cleaning_booking_system\\accounts.txt";
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
            // Append the updated data to the file
            writer.write(fullname + "," + username + "," + address + "," + number + "," + email + "," + age + "," + birthdate + "," + gender + "\n");
            writer.flush();
        } catch (IOException ex) {
            ex.printStackTrace();
            // Handle file writing error
        }
    }
    }//GEN-LAST:event_updatebutton1ActionPerformed
        
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
    java.awt.EventQueue.invokeLater(new Runnable() {
        @Override
        public void run() {
            new PERSONAL_INFO().setVisible(true);
        }
    });
}

      

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backbutton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel15;
    public javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    public javax.swing.JPanel jPanel3;
    public javax.swing.JLabel pi_address;
    public javax.swing.JLabel pi_age;
    public javax.swing.JLabel pi_birthdate;
    public javax.swing.JLabel pi_email;
    public javax.swing.JLabel pi_gender;
    public javax.swing.JLabel pi_name;
    public javax.swing.JLabel pi_number;
    public javax.swing.JLabel pi_username;
    private javax.swing.JLabel t1_txtaddress;
    private javax.swing.JLabel t1_txtage;
    private javax.swing.JLabel t1_txtbirthdate;
    private javax.swing.JLabel t1_txtemail;
    private javax.swing.JLabel t1_txtgender;
    private javax.swing.JLabel t1_txtname;
    private javax.swing.JLabel t1_txtphonenumber;
    private javax.swing.JLabel t1_txtusername;
    private javax.swing.JButton updatebutton1;
    // End of variables declaration//GEN-END:variables

   
}