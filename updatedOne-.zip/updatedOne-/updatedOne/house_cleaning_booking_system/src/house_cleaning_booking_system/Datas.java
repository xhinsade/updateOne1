/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package house_cleaning_booking_system;

/**
 *
 * @author ITLAB2-PC06-STUDENT
 */
public class Datas {
    public static String dName;
    public static String dAddress;
    public static String dEmail;
    public static String dPhoneN;
}
