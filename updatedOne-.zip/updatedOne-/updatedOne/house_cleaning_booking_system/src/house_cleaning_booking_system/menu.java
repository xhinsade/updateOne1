
package house_cleaning_booking_system;


public class menu extends javax.swing.JFrame {

    
     public menu() {
        initComponents();
    }

   
        
     
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollBar1 = new javax.swing.JScrollBar();
        jLabel3 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        pi = new javax.swing.JButton();
        BOOKINGS = new javax.swing.JButton();
        schedule = new javax.swing.JButton();
        so1 = new javax.swing.JButton();
        tc1 = new javax.swing.JButton();
        log_out = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        jLabel3.setFont(new java.awt.Font("Serif", 1, 14)); // NOI18N
        jLabel3.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2), "MY ACCOUNT", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Serif", 1, 14), new java.awt.Color(255, 255, 255))); // NOI18N

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel6.setBackground(new java.awt.Color(0, 51, 102));
        jPanel6.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createEtchedBorder(null, new java.awt.Color(102, 102, 102)), javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(51, 51, 255))));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setFont(new java.awt.Font("Verdana", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("HOUSE CLEANING BOOKING SYSTEM");
        jLabel5.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2), "WELCOME TO", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Serif", 1, 14), new java.awt.Color(255, 255, 255))); // NOI18N
        jPanel6.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(23, 8, 760, 110));

        getContentPane().add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 830, 140));

        jPanel2.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(153, 153, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pi.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        pi.setText("PERSONAL INFO");
        pi.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        pi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                piActionPerformed(evt);
            }
        });
        jPanel1.add(pi, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 40, 190, 30));

        BOOKINGS.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        BOOKINGS.setText("BOOKING");
        BOOKINGS.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        BOOKINGS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BOOKINGSActionPerformed(evt);
            }
        });
        jPanel1.add(BOOKINGS, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 90, 190, 30));

        schedule.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        schedule.setText("SCHEDULE");
        schedule.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        schedule.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                scheduleActionPerformed(evt);
            }
        });
        jPanel1.add(schedule, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 140, 190, 30));

        so1.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        so1.setText("SERVICE OFFER");
        so1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        so1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                so1ActionPerformed(evt);
            }
        });
        jPanel1.add(so1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 190, 190, 30));

        tc1.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        tc1.setText("TERMS & CONDITION");
        tc1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tc1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tc1ActionPerformed(evt);
            }
        });
        jPanel1.add(tc1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 240, 190, 30));

        log_out.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        log_out.setText("LOG - OUT");
        log_out.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        log_out.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                log_outActionPerformed(evt);
            }
        });
        jPanel1.add(log_out, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 390, 150, 30));

        jLabel1.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 5, true), "MY ACCOUNT", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Verdana", 1, 14))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 250, 440));

        jPanel2.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 270, 460));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, 830, 510));

        setSize(new java.awt.Dimension(841, 642));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void scheduleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_scheduleActionPerformed
   MY_SCHEDULE sched = new MY_SCHEDULE();
   sched.setVisible(true);
   this.dispose();
    }//GEN-LAST:event_scheduleActionPerformed

    private void BOOKINGSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BOOKINGSActionPerformed
    BOOKING1 book = new BOOKING1();
    book.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_BOOKINGSActionPerformed

    private void so1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_so1ActionPerformed
       SERVICE_OFFER offer= new SERVICE_OFFER();
       offer.setVisible(true);
       this.dispose();
    }//GEN-LAST:event_so1ActionPerformed
      
    private void piActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_piActionPerformed
    PERSONAL_INFO info = new  PERSONAL_INFO ();
    info.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_piActionPerformed

    private void log_outActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_log_outActionPerformed
      Login login = new Login();
      login.setVisible(true);
      this.dispose();
    }//GEN-LAST:event_log_outActionPerformed

    private void tc1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tc1ActionPerformed
      TERMSandCONDITION tc = new TERMSandCONDITION();
      tc.setVisible(true);
      this.dispose();
    }//GEN-LAST:event_tc1ActionPerformed
       
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            new menu().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BOOKINGS;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollBar jScrollBar1;
    private javax.swing.JButton log_out;
    private javax.swing.JButton pi;
    private javax.swing.JButton schedule;
    private javax.swing.JButton so1;
    private javax.swing.JButton tc1;
    // End of variables declaration//GEN-END:variables

    }
